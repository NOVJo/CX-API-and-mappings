# JIR_023 - SampleAPI_JIR_023

**Category:** Jira  
**From System:** SystemA  
**To System:** SystemB  
**Integration Platform:** TBD  
**Endpoint:** https://api.example.com/jira/SampleAPI_JIR_023

## Payloads
- `JIR_023_Request.json`: Example request payload

## Mapping Notes
- Add field-level mappings here

## Revisions

| Version | Date       | Author    | Description of Change                  |
|---------|------------|-----------|----------------------------------------|
| v1.0    | 2025-09-25 | Jo Camp   | Initial commit with placeholder payload |
