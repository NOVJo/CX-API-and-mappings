# 📚 API Mappings Repository

## 🔗 Table of Contents

- [QUO_001 - SampleAPI_QUO_001](API-Mappings-WithRevisionTables/Quotes/QUO_001_SampleAPI_QUO_001/README.md)

- [QUO_002 - SampleAPI_QUO_002](API-Mappings-WithRevisionTables/Quotes/QUO_002_SampleAPI_QUO_002/README.md)

- [QUO_003 - SampleAPI_QUO_003](API-Mappings-WithRevisionTables/Quotes/QUO_003_SampleAPI_QUO_003/README.md)

- [QUO_004 - SampleAPI_QUO_004](API-Mappings-WithRevisionTables/Quotes/QUO_004_SampleAPI_QUO_004/README.md)

- [QUO_005 - SampleAPI_QUO_005](API-Mappings-WithRevisionTables/Quotes/QUO_005_SampleAPI_QUO_005/README.md)

- [QUO_006 - SampleAPI_QUO_006](API-Mappings-WithRevisionTables/Quotes/QUO_006_SampleAPI_QUO_006/README.md)

- [QUO_007 - SampleAPI_QUO_007](API-Mappings-WithRevisionTables/Quotes/QUO_007_SampleAPI_QUO_007/README.md)

- [ORD_008 - SampleAPI_ORD_008](API-Mappings-WithRevisionTables/Orders/ORD_008_SampleAPI_ORD_008/README.md)

- [ORD_009 - SampleAPI_ORD_009](API-Mappings-WithRevisionTables/Orders/ORD_009_SampleAPI_ORD_009/README.md)

- [ORD_010 - SampleAPI_ORD_010](API-Mappings-WithRevisionTables/Orders/ORD_010_SampleAPI_ORD_010/README.md)

- [ORD_011 - SampleAPI_ORD_011](API-Mappings-WithRevisionTables/Orders/ORD_011_SampleAPI_ORD_011/README.md)

- [ORD_012 - SampleAPI_ORD_012](API-Mappings-WithRevisionTables/Orders/ORD_012_SampleAPI_ORD_012/README.md)

- [ORD_013 - SampleAPI_ORD_013](API-Mappings-WithRevisionTables/Orders/ORD_013_SampleAPI_ORD_013/README.md)

- [ORD_014 - SampleAPI_ORD_014](API-Mappings-WithRevisionTables/Orders/ORD_014_SampleAPI_ORD_014/README.md)

- [ERP_015 - SampleAPI_ERP_015](API-Mappings-WithRevisionTables/ERP/ERP_015_SampleAPI_ERP_015/README.md)

- [ERP_016 - SampleAPI_ERP_016](API-Mappings-WithRevisionTables/ERP/ERP_016_SampleAPI_ERP_016/README.md)

- [ERP_017 - SampleAPI_ERP_017](API-Mappings-WithRevisionTables/ERP/ERP_017_SampleAPI_ERP_017/README.md)

- [ERP_018 - SampleAPI_ERP_018](API-Mappings-WithRevisionTables/ERP/ERP_018_SampleAPI_ERP_018/README.md)

- [ERP_019 - SampleAPI_ERP_019](API-Mappings-WithRevisionTables/ERP/ERP_019_SampleAPI_ERP_019/README.md)

- [ERP_020 - SampleAPI_ERP_020](API-Mappings-WithRevisionTables/ERP/ERP_020_SampleAPI_ERP_020/README.md)

- [ERP_021 - SampleAPI_ERP_021](API-Mappings-WithRevisionTables/ERP/ERP_021_SampleAPI_ERP_021/README.md)

- [JIR_022 - SampleAPI_JIR_022](API-Mappings-WithRevisionTables/Jira/JIR_022_SampleAPI_JIR_022/README.md)

- [JIR_023 - SampleAPI_JIR_023](API-Mappings-WithRevisionTables/Jira/JIR_023_SampleAPI_JIR_023/README.md)

- [JIR_024 - SampleAPI_JIR_024](API-Mappings-WithRevisionTables/Jira/JIR_024_SampleAPI_JIR_024/README.md)

- [JIR_025 - SampleAPI_JIR_025](API-Mappings-WithRevisionTables/Jira/JIR_025_SampleAPI_JIR_025/README.md)

- [JIR_026 - SampleAPI_JIR_026](API-Mappings-WithRevisionTables/Jira/JIR_026_SampleAPI_JIR_026/README.md)

- [JIR_027 - SampleAPI_JIR_027](API-Mappings-WithRevisionTables/Jira/JIR_027_SampleAPI_JIR_027/README.md)

- [JIR_028 - SampleAPI_JIR_028](API-Mappings-WithRevisionTables/Jira/JIR_028_SampleAPI_JIR_028/README.md)

- [PRM_029 - SampleAPI_PRM_029](API-Mappings-WithRevisionTables/PRM/PRM_029_SampleAPI_PRM_029/README.md)

- [PRM_030 - SampleAPI_PRM_030](API-Mappings-WithRevisionTables/PRM/PRM_030_SampleAPI_PRM_030/README.md)

- [PRM_031 - SampleAPI_PRM_031](API-Mappings-WithRevisionTables/PRM/PRM_031_SampleAPI_PRM_031/README.md)

- [PRM_032 - SampleAPI_PRM_032](API-Mappings-WithRevisionTables/PRM/PRM_032_SampleAPI_PRM_032/README.md)

- [PRM_033 - SampleAPI_PRM_033](API-Mappings-WithRevisionTables/PRM/PRM_033_SampleAPI_PRM_033/README.md)

- [PRM_034 - SampleAPI_PRM_034](API-Mappings-WithRevisionTables/PRM/PRM_034_SampleAPI_PRM_034/README.md)

- [PRM_035 - SampleAPI_PRM_035](API-Mappings-WithRevisionTables/PRM/PRM_035_SampleAPI_PRM_035/README.md)

- [OCP_036 - SampleAPI_OCP_036](API-Mappings-WithRevisionTables/OCPQ/OCP_036_SampleAPI_OCP_036/README.md)

- [OCP_037 - SampleAPI_OCP_037](API-Mappings-WithRevisionTables/OCPQ/OCP_037_SampleAPI_OCP_037/README.md)

- [OCP_038 - SampleAPI_OCP_038](API-Mappings-WithRevisionTables/OCPQ/OCP_038_SampleAPI_OCP_038/README.md)

- [OCP_039 - SampleAPI_OCP_039](API-Mappings-WithRevisionTables/OCPQ/OCP_039_SampleAPI_OCP_039/README.md)

- [OCP_040 - SampleAPI_OCP_040](API-Mappings-WithRevisionTables/OCPQ/OCP_040_SampleAPI_OCP_040/README.md)

- [OCP_041 - SampleAPI_OCP_041](API-Mappings-WithRevisionTables/OCPQ/OCP_041_SampleAPI_OCP_041/README.md)

- [OCP_042 - SampleAPI_OCP_042](API-Mappings-WithRevisionTables/OCPQ/OCP_042_SampleAPI_OCP_042/README.md)

- [PHC_043 - SampleAPI_PHC_043](API-Mappings-WithRevisionTables/PHC/PHC_043_SampleAPI_PHC_043/README.md)

- [PHC_044 - SampleAPI_PHC_044](API-Mappings-WithRevisionTables/PHC/PHC_044_SampleAPI_PHC_044/README.md)

- [PHC_045 - SampleAPI_PHC_045](API-Mappings-WithRevisionTables/PHC/PHC_045_SampleAPI_PHC_045/README.md)

- [PHC_046 - SampleAPI_PHC_046](API-Mappings-WithRevisionTables/PHC/PHC_046_SampleAPI_PHC_046/README.md)

- [PHC_047 - SampleAPI_PHC_047](API-Mappings-WithRevisionTables/PHC/PHC_047_SampleAPI_PHC_047/README.md)

- [PHC_048 - SampleAPI_PHC_048](API-Mappings-WithRevisionTables/PHC/PHC_048_SampleAPI_PHC_048/README.md)

- [PHC_049 - SampleAPI_PHC_049](API-Mappings-WithRevisionTables/PHC/PHC_049_SampleAPI_PHC_049/README.md)

- [TPH_050 - SampleAPI_TPH_050](API-Mappings-WithRevisionTables/TPH/TPH_050_SampleAPI_TPH_050/README.md)

- [TPH_051 - SampleAPI_TPH_051](API-Mappings-WithRevisionTables/TPH/TPH_051_SampleAPI_TPH_051/README.md)

- [TPH_052 - SampleAPI_TPH_052](API-Mappings-WithRevisionTables/TPH/TPH_052_SampleAPI_TPH_052/README.md)

- [TPH_053 - SampleAPI_TPH_053](API-Mappings-WithRevisionTables/TPH/TPH_053_SampleAPI_TPH_053/README.md)

- [TPH_054 - SampleAPI_TPH_054](API-Mappings-WithRevisionTables/TPH/TPH_054_SampleAPI_TPH_054/README.md)

- [TPH_055 - SampleAPI_TPH_055](API-Mappings-WithRevisionTables/TPH/TPH_055_SampleAPI_TPH_055/README.md)

- [TPH_056 - SampleAPI_TPH_056](API-Mappings-WithRevisionTables/TPH/TPH_056_SampleAPI_TPH_056/README.md)

- [RIG_057 - SampleAPI_RIG_057](API-Mappings-WithRevisionTables/RigVessel/RIG_057_SampleAPI_RIG_057/README.md)

- [RIG_058 - SampleAPI_RIG_058](API-Mappings-WithRevisionTables/RigVessel/RIG_058_SampleAPI_RIG_058/README.md)

- [RIG_059 - SampleAPI_RIG_059](API-Mappings-WithRevisionTables/RigVessel/RIG_059_SampleAPI_RIG_059/README.md)

- [RIG_060 - SampleAPI_RIG_060](API-Mappings-WithRevisionTables/RigVessel/RIG_060_SampleAPI_RIG_060/README.md)

- [RIG_061 - SampleAPI_RIG_061](API-Mappings-WithRevisionTables/RigVessel/RIG_061_SampleAPI_RIG_061/README.md)

- [RIG_062 - SampleAPI_RIG_062](API-Mappings-WithRevisionTables/RigVessel/RIG_062_SampleAPI_RIG_062/README.md)

- [RIG_063 - SampleAPI_RIG_063](API-Mappings-WithRevisionTables/RigVessel/RIG_063_SampleAPI_RIG_063/README.md)
